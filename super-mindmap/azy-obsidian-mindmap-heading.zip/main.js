var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => ZYHeadingShifter
});
module.exports = __toCommonJS(main_exports);
var import_obsidian5 = require("obsidian");

// src/settings.ts
var import_obsidian = require("obsidian");
var DEFAULT_SETTINGS = {
  limitHeadingFrom: 1,
  overrideTab: false
};

// src/services/obsidianService.ts
var import_obsidian2 = require("obsidian");
var ZYObsidianService = class {
  constructor() {
  }
  getEditorFromState(state) {
    return state.field(import_obsidian2.editorViewField).editor;
  }
  createKeymapRunCallback(config) {
    const check = config.check || (() => true);
    const { run } = config;
    return (view) => {
      const editor = this.getEditorFromState(view.state);
      if (!check(editor)) {
        return false;
      }
      const shouldStopPropagation = run(editor);
      return shouldStopPropagation;
    };
  }
};

// src/services/interfaceService.ts
var import_obsidian3 = require("obsidian");

// src/ui/icon.ts
var icon_increase_heading = `
<path d="M100 50L81.25 68.1865L81.25 31.8135L100 50Z" fill="currentColor" />
<line x1="5" y1="37" x2="73" y2="37"  stroke="currentColor" stroke-width="10" stroke-linecap="round" />
<line x1="52" y1="8" x2="52" y2="92"  stroke="currentColor" stroke-width="10" stroke-linecap="round" />
<line x1="5" y1="62" x2="73" y2="62"  stroke="currentColor" stroke-width="10" stroke-linecap="round" />
<line x1="27" y1="8" x2="27" y2="92"  stroke="currentColor" stroke-width="10" stroke-linecap="round" />`;
var icon_decrease_heading = `<path d="M2.50422e-07 50L18.75 31.8135L18.75 68.1865L2.50422e-07 50Z" fill="currentColor" />
<line x1="27" y1="37" x2="95" y2="37"  stroke="currentColor" stroke-width="10" stroke-linecap="round" />
<line x1="74" y1="8" x2="74" y2="92"  stroke="currentColor" stroke-width="10" stroke-linecap="round" />
<line x1="27" y1="62" x2="95" y2="62"  stroke="currentColor" stroke-width="10" stroke-linecap="round" />
<line x1="49" y1="8" x2="49" y2="92"  stroke="currentColor" stroke-width="10" stroke-linecap="round" />
`;
var icon_heading_0 = `
<path d="M12 22H88"  stroke="currentColor" stroke-width="10" stroke-linecap="round"/>
<line x1="71" y1="8" x2="71" y2="92"  stroke="currentColor" stroke-width="10" stroke-linecap="round"/>
<path d="M48.9929 65.7955C46.3509 65.786 44.0687 65.1752 42.1463 63.9631C40.224 62.7509 38.742 61.0038 37.7003 58.7216C36.6586 56.4394 36.1425 53.7027 36.152 50.5114C36.1615 47.3106 36.6823 44.5928 37.7145 42.358C38.7562 40.1231 40.2334 38.4233 42.1463 37.2585C44.0687 36.0937 46.3509 35.5114 48.9929 35.5114C51.6349 35.5114 53.9171 36.0985 55.8395 37.2727C57.7618 38.4375 59.2438 40.1373 60.2855 42.3722C61.3272 44.607 61.8433 47.3201 61.8338 50.5114C61.8338 53.7216 61.313 56.4678 60.2713 58.75C59.2296 61.0322 57.7476 62.7794 55.8253 63.9915C53.9124 65.1941 51.6349 65.7955 48.9929 65.7955ZM48.9929 59.375C50.3565 59.375 51.474 58.6648 52.3452 57.2443C53.2259 55.8144 53.6615 53.5701 53.652 50.5114C53.652 48.5133 53.4531 46.8797 53.0554 45.6108C52.6577 44.3419 52.1084 43.4044 51.4077 42.7983C50.7069 42.1828 49.902 41.875 48.9929 41.875C47.6293 41.875 46.5166 42.5663 45.6548 43.9489C44.7931 45.3314 44.3527 47.5189 44.3338 50.5114C44.3243 52.5473 44.5185 54.2235 44.9162 55.5398C45.3139 56.8466 45.8632 57.8125 46.5639 58.4375C47.2741 59.0625 48.0838 59.375 48.9929 59.375Z"  fill="currentColor"/>
<line x1="11" y1="78" x2="89" y2="78"  stroke="currentColor" stroke-width="10" stroke-linecap="round"/>
<path d="M28 8L28 92"  stroke="currentColor" stroke-width="10" stroke-linecap="round"/>`;
var icon_heading_1 = `
<path d="M12 22H88"  stroke="currentColor" stroke-width="10" stroke-linecap="round"/>
<line x1="71" y1="8" x2="71" y2="92"  stroke="currentColor" stroke-width="10" stroke-linecap="round"/>
<path d="M55.576 35.9091V65H47.6783V43.1818H47.5078L41.1442 46.9886V40.2841L48.3033 35.9091H55.576Z"  fill="currentColor"/>
<line x1="11" y1="78" x2="89" y2="78"  stroke="currentColor" stroke-width="10" stroke-linecap="round"/>
<path d="M28 8L28 92"  stroke="currentColor" stroke-width="10" stroke-linecap="round"/>`;
var icon_heading_2 = `
<path d="M12 22H88"  stroke="currentColor" stroke-width="10" stroke-linecap="round"/>
<line x1="71" y1="8" x2="71" y2="92"  stroke="currentColor" stroke-width="10" stroke-linecap="round"/>
<path d="M38.0021 65V59.3182L48.8544 50.3409C49.5741 49.7443 50.1896 49.1856 50.701 48.6648C51.2218 48.1345 51.6196 47.59 51.8942 47.0312C52.1783 46.4725 52.3203 45.8523 52.3203 45.1705C52.3203 44.4223 52.1593 43.7831 51.8374 43.2528C51.5249 42.7225 51.0893 42.3153 50.5305 42.0312C49.9718 41.7377 49.3279 41.5909 48.5987 41.5909C47.8696 41.5909 47.2256 41.7377 46.6669 42.0312C46.1177 42.3248 45.6915 42.7557 45.3885 43.3239C45.0855 43.892 44.9339 44.5833 44.9339 45.3977H37.4339C37.4339 43.3523 37.8932 41.5909 38.8118 40.1136C39.7304 38.6364 41.0277 37.5 42.7038 36.7045C44.38 35.9091 46.3449 35.5114 48.5987 35.5114C50.9283 35.5114 52.9453 35.8854 54.6499 36.6335C56.3639 37.3722 57.6849 38.4138 58.6129 39.7585C59.5504 41.1032 60.0192 42.6799 60.0192 44.4886C60.0192 45.6061 59.7872 46.7187 59.3232 47.8267C58.8591 48.9252 58.0258 50.142 56.8232 51.4773C55.6205 52.8125 53.9112 54.4034 51.6953 56.25L48.968 58.5227V58.6932H60.3317V65H38.0021Z"  fill="currentColor"/>
<line x1="11" y1="78" x2="89" y2="78"  stroke="currentColor" stroke-width="10" stroke-linecap="round"/>
<path d="M28 8L28 92"  stroke="currentColor" stroke-width="10" stroke-linecap="round"/>`;
var icon_heading_3 = `
<path d="M12 22H88"  stroke="currentColor" stroke-width="10" stroke-linecap="round"/>
<line x1="71" y1="8" x2="71" y2="92"  stroke="currentColor" stroke-width="10" stroke-linecap="round"/>
<path d="M49.2994 65.3977C47.0077 65.3977 44.9717 65.0047 43.1914 64.2188C41.4206 63.4233 40.0285 62.3295 39.0153 60.9375C38.002 59.5455 37.4906 57.9451 37.4812 56.1364H45.4357C45.4452 56.6951 45.6156 57.197 45.9471 57.642C46.288 58.0777 46.752 58.4186 47.3391 58.6648C47.9263 58.911 48.5986 59.0341 49.3562 59.0341C50.0853 59.0341 50.7293 58.9062 51.288 58.6506C51.8467 58.3854 52.2823 58.0208 52.5948 57.5568C52.9073 57.0928 53.0588 56.5625 53.0494 55.9659C53.0588 55.3788 52.8789 54.858 52.5096 54.4034C52.1497 53.9489 51.6431 53.5937 50.9897 53.3381C50.3363 53.0824 49.5835 52.9545 48.7312 52.9545H45.7766V47.5H48.7312C49.5172 47.5 50.2085 47.3722 50.805 47.1165C51.4111 46.8608 51.8799 46.5057 52.2113 46.0511C52.5522 45.5966 52.7179 45.0758 52.7085 44.4886C52.7179 43.9205 52.5806 43.4186 52.2965 42.983C52.0124 42.5473 51.6147 42.2064 51.1033 41.9602C50.6014 41.714 50.0191 41.5909 49.3562 41.5909C48.6365 41.5909 47.9925 41.7187 47.4244 41.9744C46.8656 42.2301 46.4253 42.5852 46.1033 43.0398C45.7814 43.4943 45.6156 44.0152 45.6062 44.6023H38.0494C38.0588 42.822 38.5465 41.25 39.5124 39.8864C40.4878 38.5227 41.823 37.4527 43.5181 36.6761C45.2132 35.8996 47.1592 35.5114 49.3562 35.5114C51.5058 35.5114 53.4045 35.8759 55.0522 36.6051C56.7094 37.3343 58.002 38.3381 58.93 39.6165C59.8675 40.8854 60.3316 42.339 60.3221 43.9773C60.341 45.6061 59.7823 46.9413 58.646 47.983C57.5191 49.0246 56.0891 49.6402 54.3562 49.8295V50.0568C56.7047 50.3125 58.4708 51.0322 59.6545 52.2159C60.8382 53.3902 61.4206 54.8674 61.4016 56.6477C61.4111 58.3523 60.8997 59.8627 59.8675 61.179C58.8448 62.4953 57.4196 63.5275 55.592 64.2756C53.7738 65.0237 51.6763 65.3977 49.2994 65.3977Z"  fill="currentColor"/>
<line x1="11" y1="78" x2="89" y2="78"  stroke="currentColor" stroke-width="10" stroke-linecap="round"/>
<path d="M28 8L28 92"  stroke="currentColor" stroke-width="10" stroke-linecap="round"/>`;
var icon_heading_4 = `
<path d="M12 22H88"  stroke="currentColor" stroke-width="10" stroke-linecap="round"/>
<line x1="71" y1="8" x2="71" y2="92"  stroke="currentColor" stroke-width="10" stroke-linecap="round"/>
<path d="M37.1048 60.4545V54.3182L48.8093 35.9091H54.3775V44.0909H51.1957L44.8888 54.0909V54.3182H62.1616V60.4545H37.1048ZM51.2525 65V58.5795L51.4229 55.9091V35.9091H58.8093V65H51.2525Z"  fill="currentColor"/>
<line x1="11" y1="78" x2="89" y2="78"  stroke="currentColor" stroke-width="10" stroke-linecap="round"/>
<path d="M28 8L28 92"  stroke="currentColor" stroke-width="10" stroke-linecap="round"/>`;
var icon_heading_5 = `
<path d="M12 22H88"  stroke="currentColor" stroke-width="10" stroke-linecap="round"/>
<line x1="71" y1="8" x2="71" y2="92"  stroke="currentColor" stroke-width="10" stroke-linecap="round"/>
<path d="M49.7006 65.3977C47.4658 65.3977 45.4819 65.0047 43.7489 64.2188C42.0254 63.4233 40.6665 62.3295 39.6722 60.9375C38.6874 59.5455 38.1855 57.9451 38.1665 56.1364H45.837C45.8654 57.1402 46.2537 57.9403 47.0018 58.5369C47.7594 59.1335 48.659 59.4318 49.7006 59.4318C50.5056 59.4318 51.2158 59.2614 51.8313 58.9205C52.4469 58.5701 52.9298 58.0777 53.2802 57.4432C53.6306 56.8087 53.801 56.0701 53.7915 55.2273C53.801 54.375 53.6306 53.6364 53.2802 53.0114C52.9298 52.3769 52.4469 51.8892 51.8313 51.5483C51.2158 51.1979 50.5056 51.0227 49.7006 51.0227C48.8673 51.0227 48.0955 51.2263 47.3853 51.6335C46.6845 52.0312 46.1684 52.5852 45.837 53.2955L38.9052 51.9318L40.0415 35.9091H59.587V42.2159H46.5188L45.9506 48.6364H46.1211C46.5756 47.7557 47.3616 47.0265 48.479 46.4489C49.5965 45.8617 50.8938 45.5682 52.3711 45.5682C54.104 45.5682 55.6476 45.9706 57.0018 46.7756C58.3654 47.5805 59.4402 48.6932 60.2262 50.1136C61.0217 51.5246 61.4147 53.1534 61.4052 55C61.4147 57.0265 60.9317 58.8258 59.9563 60.3977C58.9904 61.9602 57.6315 63.1866 55.8796 64.0767C54.1277 64.9574 52.0681 65.3977 49.7006 65.3977Z"  fill="currentColor"/>
<line x1="11" y1="78" x2="89" y2="78"  stroke="currentColor" stroke-width="10" stroke-linecap="round"/>
<path d="M28 8L28 92"  stroke="currentColor" stroke-width="10" stroke-linecap="round"/>`;
var icon_heading_6 = `
<path d="M12 22H88"  stroke="currentColor" stroke-width="10" stroke-linecap="round"/>
<line x1="71" y1="8" x2="71" y2="92"  stroke="currentColor" stroke-width="10" stroke-linecap="round"/>
<path d="M49.3995 65.3977C47.7044 65.3977 46.0946 65.1326 44.57 64.6023C43.0548 64.0625 41.7101 63.215 40.5359 62.0597C39.3616 60.9044 38.4383 59.3987 37.766 57.5426C37.1031 55.6866 36.7764 53.4375 36.7859 50.7955C36.7953 48.4375 37.0984 46.3163 37.695 44.4318C38.301 42.5473 39.158 40.9422 40.266 39.6165C41.3834 38.2907 42.7186 37.2775 44.2717 36.5767C45.8247 35.8665 47.5529 35.5114 49.4563 35.5114C51.5965 35.5114 53.4809 35.9233 55.1097 36.7472C56.7385 37.571 58.0359 38.6742 59.0018 40.0568C59.9772 41.4299 60.5453 42.9451 60.7063 44.6023H52.9222C52.7423 43.7784 52.3256 43.1771 51.6722 42.7983C51.0283 42.41 50.2897 42.2159 49.4563 42.2159C47.7991 42.2159 46.5823 42.9356 45.8058 44.375C45.0387 45.8144 44.6457 47.7083 44.6268 50.0568H44.7972C45.1665 49.1667 45.7253 48.4044 46.4734 47.7699C47.2215 47.1354 48.0927 46.6477 49.087 46.3068C50.0813 45.9659 51.1325 45.7955 52.2404 45.7955C54.0018 45.7955 55.5406 46.1932 56.8569 46.9886C58.1826 47.7841 59.2148 48.8731 59.9535 50.2557C60.6921 51.6383 61.0567 53.2197 61.0472 55C61.0567 57.0833 60.5643 58.9062 59.57 60.4688C58.5851 62.0312 57.2167 63.2434 55.4648 64.1051C53.713 64.9669 51.6912 65.3977 49.3995 65.3977ZM49.3427 59.4318C50.1287 59.4318 50.8247 59.2519 51.4308 58.892C52.0463 58.5322 52.5245 58.0398 52.8654 57.4148C53.2158 56.7898 53.3862 56.0795 53.3768 55.2841C53.3862 54.4792 53.2158 53.7689 52.8654 53.1534C52.5245 52.5284 52.0463 52.036 51.4308 51.6761C50.8247 51.3163 50.1287 51.1364 49.3427 51.1364C48.765 51.1364 48.23 51.2405 47.7376 51.4489C47.2546 51.6477 46.8332 51.9366 46.4734 52.3153C46.1135 52.6847 45.8294 53.125 45.6211 53.6364C45.4222 54.1383 45.3181 54.6875 45.3086 55.2841C45.3181 56.0795 45.498 56.7898 45.8484 57.4148C46.1987 58.0398 46.677 58.5322 47.283 58.892C47.8891 59.2519 48.5756 59.4318 49.3427 59.4318Z"  fill="currentColor"/>
<line x1="11" y1="78" x2="89" y2="78"  stroke="currentColor" stroke-width="10" stroke-linecap="round"/>
<path d="M28 8L28 92"  stroke="currentColor" stroke-width="10" stroke-linecap="round"/>`;

// src/services/interfaceService.ts
var ZYInterfaceService = class {
  constructor() {
    __publicField(this, "addIcons", () => {
      (0, import_obsidian3.addIcon)("headingShifter_decreaseIcon", icon_decrease_heading);
      (0, import_obsidian3.addIcon)("headingShifter_increaseIcon", icon_increase_heading);
      (0, import_obsidian3.addIcon)("headingShifter_heading0", icon_heading_0);
      (0, import_obsidian3.addIcon)("headingShifter_heading1", icon_heading_1);
      (0, import_obsidian3.addIcon)("headingShifter_heading2", icon_heading_2);
      (0, import_obsidian3.addIcon)("headingShifter_heading3", icon_heading_3);
      (0, import_obsidian3.addIcon)("headingShifter_heading4", icon_heading_4);
      (0, import_obsidian3.addIcon)("headingShifter_heading5", icon_heading_5);
      (0, import_obsidian3.addIcon)("headingShifter_heading6", icon_heading_6);
    });
  }
  exec() {
    this.addIcons();
  }
};

// src/features/shiftHeading/operation.ts
var import_obsidian4 = require("obsidian");

// src/features/applyHeading/module.ts
var applyHeading = (chunk, headingSize) => {
  const remove = chunk.replace(/^#+ /, "").replace(/^(\-|\*|\d+\.) /, "");
  if (headingSize == 0)
    return remove;
  if (headingSize == -1)
    return "	" + remove;
  return new Array(headingSize).fill("#").reduce((prev, cur) => {
    return cur + prev;
  }, " ") + remove;
};

// src/utils/range.ts
var setMin = (prev, cur) => {
  if (prev == void 0 || prev !== void 0 && cur < prev) {
    return cur;
  }
  return prev;
};
var setMax = (prev, cur) => {
  if (prev == void 0 || prev !== void 0 && cur > prev) {
    return cur;
  }
  return prev;
};

// src/utils/markdown.ts
var checkHeading = (content) => {
  const match = content.match(/^(#+)( |$)/);
  if (!match || !match[1])
    return 0;
  return match[1].length;
};
var checkCharactorHeading = (content) => {
  return !content.startsWith(" ");
};
var checkTabOr4SpacePrefix = (content) => {
  return content.startsWith("    ") || content.startsWith("	");
};
var checkFence = (content) => {
  const backticks = content.match(/^(`{3,})/);
  if (backticks && backticks[1])
    return { fenceType: "`", fenceNum: backticks[1].length };
  const tildes = content.match(/^(~{3,})/);
  if (tildes && tildes[1])
    return { fenceType: "~", fenceNum: tildes[1].length };
  return null;
};
var getFenceStatus = (prev, current) => {
  if (!current)
    return prev;
  if (!prev)
    return current;
  if (current.fenceType == prev.fenceType && current.fenceNum >= prev.fenceNum) {
    return null;
  }
  return prev;
};
var getHeadingLines = (editor, from, to) => {
  let headingLines = [];
  let normalLines = [];
  let minHeading = void 0;
  let maxHeading = void 0;
  let fence = null;
  let hasTabPrefix = false;
  for (let line = Math.min(from, to); line <= Math.max(from, to); line++) {
    fence = getFenceStatus(fence, checkFence(editor.getLine(line)));
    if (fence)
      continue;
    const lineStr = editor.getLine(line);
    const heading = checkHeading(lineStr);
    if (heading > 0) {
      headingLines.push(line);
      minHeading = setMin(minHeading, heading);
      maxHeading = setMax(maxHeading, heading);
    } else {
      normalLines.push(line);
      if (lineStr.startsWith("	")) {
        hasTabPrefix = true;
      }
    }
  }
  if (hasTabPrefix) {
    normalLines = [];
  }
  return { headingLines, minHeading, maxHeading, normalLines };
};
var getTabLines = (editor, from, to) => {
  let headingLines = [];
  let unShiftLines = [];
  let emptyLines = [];
  let firstHeadingLine = -1;
  let hasPreSpace = false;
  let minline = Math.min(from, to);
  if (minline > 0 && editor.getLine(minline - 1).trim() === "") {
    hasPreSpace = true;
  }
  for (let line2 = Math.min(from, to); line2 <= Math.max(from, to); line2++) {
    const lineStr = editor.getLine(line2);
    if (lineStr.trim() === "") {
      emptyLines.push(line2);
      continue;
    }
    const res = checkCharactorHeading(lineStr);
    if (res) {
      if (hasPreSpace && firstHeadingLine < 0) {
        firstHeadingLine = line2;
      }
      headingLines.push(line2);
    } else if (checkTabOr4SpacePrefix(editor.getLine(line2))) {
      unShiftLines.push(line2);
    }
  }
  let heading = -1;
  let line = Math.min(from, to);
  while (heading <= 0 && line > 0) {
    line = line - 1;
    heading = checkHeading(editor.getLine(line));
  }
  if (heading <= 0) {
    heading = 1;
  }
  return {
    firstHeadingLine,
    headingLines,
    heading,
    unShiftLines,
    emptyLines
  };
};

// src/utils/editorChange.ts
var composeLineChanges = (editor, lineNumbers, changeCallback, heading = 0) => {
  const editorChange = [];
  for (const line of lineNumbers) {
    const shifted = changeCallback(editor.getLine(line), heading, line);
    if (shifted != void 0) {
      editorChange.push({
        text: shifted,
        from: { line, ch: 0 },
        to: {
          line,
          ch: editor.getLine(line).length
        }
      });
    } else {
      editorChange.push({
        text: "\n",
        from: { line: line - 1, ch: editor.getLine(line - 1).length },
        to: { line: line + 1, ch: 0 }
      });
    }
  }
  return editorChange;
};
var composeLineToTabChanges = (editor, lineNumbers, from, to) => {
  const editorChange = [];
  let firstLineHeading = 0;
  let deltaTab = 0;
  const minLine = Math.min(from, to);
  const maxLine = Math.max(from, to);
  for (let i = minLine; i <= maxLine; i++) {
    let line = -1;
    if (lineNumbers.contains(i)) {
      line = i;
    } else {
      let curTxtLine = editor.getLine(i);
      if (curTxtLine.trim().length <= 0) {
        continue;
      }
      if (deltaTab > 0 && deltaTab < 10) {
        let repeat = deltaTab;
        while (repeat > 0) {
          curTxtLine = "    " + curTxtLine;
          repeat--;
        }
      }
      editorChange.push({
        text: curTxtLine,
        from: { line: i, ch: 0 },
        to: {
          line: i,
          ch: editor.getLine(i).length
        }
      });
      continue;
    }
    const preLine = line - 1;
    if (preLine >= 0 && editor.getLine(preLine).trim() === "") {
      editorChange.push({
        text: "",
        from: { line: preLine, ch: 0 },
        to: {
          line,
          ch: 0
        }
      });
    }
    let chunk = editor.getLine(line);
    const headingNum = checkHeading(chunk);
    if (line == lineNumbers[0]) {
      firstLineHeading = headingNum;
    }
    deltaTab = headingNum - firstLineHeading + 1;
    let result = chunk;
    if (headingNum > 0) {
      result = applyHeading(chunk, 0);
      for (let i2 = 0; i2 < headingNum - firstLineHeading; i2++) {
        result = "    " + result;
      }
    }
    editorChange.push({
      text: result,
      from: { line, ch: 0 },
      to: {
        line,
        ch: editor.getLine(line).length
      }
    });
  }
  return editorChange;
};

// src/features/shiftHeading/module.ts
var shiftHeading = (chunk, dir) => {
  const heading = checkHeading(chunk);
  return applyHeading(chunk, heading + dir);
};
var increaseHeading = (chunk, heading) => {
  return shiftHeading(chunk, 1);
};
var getPreTabOr4SpaceAndOtherPrefix = (chunk, heading) => {
  let type = "    ";
  if (chunk.startsWith("	")) {
    type = "	";
  }
  let preSpace = "";
  while (chunk.startsWith(type)) {
    preSpace = "    " + preSpace;
    chunk = chunk.replace(type, "");
  }
  let prefix = null;
  if (chunk.trimStart().startsWith("- ")) {
    prefix = "- ";
  }
  return { preSpace, prefix };
};
var unshiftTabOr4Space = (chunk, heading) => {
  const code0 = chunk.length > 0 ? chunk.charCodeAt(0) : 0;
  if (chunk.startsWith("	")) {
    chunk = chunk.replace("	", "");
  } else if (code0 == 8195 || code0 == 12288) {
    const codeChar = String.fromCharCode(code0);
    chunk = chunk.replace(codeChar, "");
    chunk = chunk.replace(codeChar, "");
  } else if (chunk.startsWith(" ")) {
    let chunkPreSpaceLen = chunk.length;
    for (let i = 0; i < chunk.length; i++) {
      if (chunk[i] != " ") {
        chunkPreSpaceLen = i;
        break;
      }
    }
    let left = chunkPreSpaceLen % 4;
    if (left == 0) {
      left = 4;
    }
    for (let i = 0; i < left; i++) {
      if (chunk.startsWith(" ")) {
        chunk = chunk.replace(" ", "");
      }
    }
  }
  return chunk;
};
var shiftTabOr4Space = (chunk, heading) => {
  let chunkPreSpaceLen = chunk.length;
  for (let i = 0; i < chunk.length; i++) {
    if (chunk[i] != " ") {
      chunkPreSpaceLen = i;
      break;
    }
  }
  let left = 4 - chunkPreSpaceLen % 4;
  if (left == 0) {
    left = 4;
  }
  const origin = chunk;
  for (let i = 0; i < left; i++) {
    chunk = " " + chunk;
  }
  return chunk;
};
var decreaseHeading = (chunk, heading) => {
  return shiftHeading(chunk, -1);
};

// src/features/shiftHeading/operation.ts
var ZYTODOToggleOperation = class {
  constructor(settings) {
    __publicField(this, "settings");
    __publicField(this, "editorCallback", (editor) => {
      const from = editor.getCursor("from").line;
      const to = editor.getCursor("to").line;
      const code0 = "\u{1F518}";
      const code1 = "\u2705";
      const code2 = "\u274C";
      const firstline = Math.min(from, to);
      const lineStr = editor.getLine(firstline);
      let type = 0;
      if (lineStr.contains(code0)) {
        type = 1;
      } else if (lineStr.contains(code1)) {
        type = 2;
      } else if (lineStr.contains(code2)) {
        type = 3;
      }
      for (let line = Math.min(from, to); line <= Math.max(from, to); line++) {
        let curStr = editor.getLine(line);
        if (type == 1) {
          curStr = curStr.replace(code0, code1);
        } else if (type == 2) {
          curStr = curStr.replace(`${code1} `, `${code0} `);
        } else if (type == 3) {
          curStr = curStr.replace(`${code2} `, `${code0} `);
        } else {
          let { preSpace, prefix } = getPreTabOr4SpaceAndOtherPrefix(curStr, 0);
          let trimStart = curStr.trimStart();
          curStr = `${preSpace}${code0} ${trimStart}`;
        }
        editor.setLine(line, curStr);
      }
      return true;
    });
    __publicField(this, "createCommand", () => {
      const cmdId = "todo-toggle";
      return {
        id: cmdId,
        name: cmdId,
        icon: cmdId,
        editorCallback: this.editorCallback
      };
    });
    __publicField(this, "check", () => {
      return true;
    });
    this.settings = settings;
  }
};
var TabTypeToggleOperation = class {
  constructor(settings) {
    __publicField(this, "settings");
    __publicField(this, "editorCallback", (editor) => {
      let page = editor.getValue();
      const code0 = 8195;
      const code1 = 12288;
      const codeChar0 = String.fromCharCode(code0);
      const codeChar1 = String.fromCharCode(code1);
      if (page.contains(codeChar0)) {
        page = page.replace(new RegExp(codeChar0 + codeChar0, "g"), "    ");
      } else if (page.contains(codeChar1)) {
        page = page.replace(new RegExp(codeChar1 + codeChar1, "g"), "    ");
      } else {
        page = page.replace(new RegExp("    ", "g"), codeChar1 + codeChar1);
      }
      editor.setValue(page);
      return true;
    });
    __publicField(this, "createCommand", () => {
      const cmdId = "tabType-toggle";
      return {
        id: cmdId,
        name: cmdId,
        icon: cmdId,
        editorCallback: this.editorCallback
      };
    });
    __publicField(this, "check", () => {
      return true;
    });
    this.settings = settings;
  }
};
var ZYEnterOperation = class {
  constructor(settings) {
    __publicField(this, "settings");
    __publicField(this, "editorCallback", (editor) => {
      let headCursor = editor.getCursor("head");
      let editorChange = [];
      let lineStr = editor.getLine(headCursor.line);
      const { preSpace, prefix } = getPreTabOr4SpaceAndOtherPrefix(lineStr, 0);
      const linePlaceHoder = preSpace + (prefix != null ? prefix : "");
      editorChange.push({
        text: "\n" + linePlaceHoder,
        from: headCursor,
        to: headCursor
      });
      editor.transaction({
        changes: editorChange,
        selection: { from: { line: headCursor.line + 1, ch: linePlaceHoder.length } }
      });
      return true;
    });
    __publicField(this, "createCommand", () => {
      return {
        id: "test-enter",
        name: "test-enter",
        icon: "test-enter",
        editorCallback: this.editorCallback
      };
    });
    __publicField(this, "check", (editor) => {
      if (!editor || !editor.hasFocus()) {
        return false;
      }
      const lineStr = editor.getLine(editor.getCursor().line);
      const trimS = lineStr.trimStart();
      if (trimS.startsWith("|")) {
        return false;
      }
      let regex = /^\d+.\ /;
      if (regex.test(trimS)) {
        return false;
      }
      regex = /^[-*+]\ /;
      if (regex.test(trimS)) {
        return false;
      }
      return true;
    });
    this.settings = settings;
  }
};
var ZYDecreaseHeading = class {
  constructor(settings) {
    __publicField(this, "settings");
    __publicField(this, "editorCallback", (editor) => {
      const { headingLines, minHeading, normalLines } = getHeadingLines(editor, editor.getCursor("from").line, editor.getCursor("to").line);
      if (minHeading !== void 0 && minHeading <= Number(this.settings.limitHeadingFrom)) {
        new import_obsidian4.Notice(`Cannot Decrease (contains less than Heading${Number(this.settings.limitHeadingFrom)})`);
        return true;
      }
      let editorChange = [];
      if (headingLines.length) {
        editorChange = composeLineChanges(editor, headingLines, decreaseHeading, 0);
      } else if (normalLines) {
        editorChange = composeLineChanges(editor, normalLines, unshiftTabOr4Space);
      }
      applyTransation(editor, editorChange);
      return editorChange.length ? true : false;
    });
    __publicField(this, "createCommand", () => {
      return {
        id: "decrease-heading",
        name: "Decrease Headings",
        icon: "headingShifter_decreaseIcon",
        editorCallback: this.editorCallback
      };
    });
    __publicField(this, "check", (editor) => {
      if (!editor || !editor.hasFocus()) {
        return false;
      }
      const lineStr = editor.getLine(editor.getCursor().line);
      if (lineStr.trimStart().startsWith("|")) {
        return false;
      }
      return true;
    });
    this.settings = settings;
  }
};
var ZYIncreaseHeading = class {
  constructor(settings) {
    __publicField(this, "settings");
    __publicField(this, "editorCallback", (editor) => {
      const { headingLines, maxHeading, normalLines } = getHeadingLines(editor, editor.getCursor("from").line, editor.getCursor("to").line);
      if (maxHeading !== void 0 && maxHeading >= 100) {
        new import_obsidian4.Notice("Cannot Increase (contains more than Heading 10)");
        return true;
      }
      let editorChange = [];
      if (headingLines.length) {
        editorChange = composeLineChanges(editor, headingLines, increaseHeading, 0);
      } else if (normalLines) {
        editorChange = composeLineChanges(editor, normalLines, shiftTabOr4Space);
      }
      applyTransation(editor, editorChange);
      return editorChange.length ? true : false;
    });
    __publicField(this, "createCommand", () => {
      return {
        id: "increase-heading",
        name: "Increase Headings",
        icon: "headingShifter_increaseIcon",
        editorCallback: this.editorCallback
      };
    });
    __publicField(this, "check", (editor) => {
      if (!editor || !editor.hasFocus()) {
        return false;
      }
      const lineStr = editor.getLine(editor.getCursor().line);
      if (lineStr.trimStart().startsWith("|")) {
        return false;
      }
      return true;
    });
    this.settings = settings;
  }
};
var ZYChangeHeading = class {
  constructor(settings, levelup = true) {
    __publicField(this, "settings");
    __publicField(this, "levelUp");
    __publicField(this, "editorCallback", (editor) => {
      const { headingLines, maxHeading } = getHeadingLines(editor, editor.getCursor("from").line, editor.getCursor("to").line);
      if (headingLines.length > 0) {
        const editorChange2 = composeLineToTabChanges(editor, headingLines, editor.getCursor("from").line, editor.getCursor("to").line);
        editor.transaction({
          changes: editorChange2
        });
        return true;
      }
      const { firstHeadingLine, headingLines: tabLines, heading, unShiftLines, emptyLines } = getTabLines(editor, editor.getCursor("from").line, editor.getCursor("to").line);
      let editorChange = composeLineChanges(editor, tabLines, (chunk, heading2, lineNumber) => {
        chunk = chunk.trim();
        let prefix = "\n";
        if (lineNumber == firstHeadingLine || lineNumber == 0) {
          prefix = "";
        }
        return prefix + applyHeading(chunk, heading2 + (this.levelUp ? 1 : 0));
      }, heading);
      let unsfitChange = composeLineChanges(editor, unShiftLines, unshiftTabOr4Space);
      let emptyChange = composeLineChanges(editor, emptyLines, (chunk, heading2) => {
        return void 0;
      });
      editor.transaction({
        changes: [...editorChange, ...unsfitChange, ...emptyChange]
      });
      return true;
    });
    __publicField(this, "createCommand", () => {
      let lstr = this.levelUp ? "-up" : "";
      return {
        id: "change-heading" + lstr,
        name: "Change Headings" + lstr,
        icon: "headingShifter_changeToHeading",
        editorCallback: this.editorCallback
      };
    });
    __publicField(this, "check", () => {
      return true;
    });
    this.settings = settings;
    this.levelUp = levelup;
  }
};
var ZYChangeAllHeading = class {
  constructor(settings, levelup = true) {
    __publicField(this, "settings");
    __publicField(this, "levelUp");
    __publicField(this, "editorCallback", (editor) => {
      const { headingLines, maxHeading } = getHeadingLines(editor, editor.getCursor("from").line, editor.getCursor("to").line);
      if (headingLines.length > 0) {
        const editorChange2 = composeLineToTabChanges(editor, headingLines, editor.getCursor("from").line, editor.getCursor("to").line);
        editor.transaction({
          changes: editorChange2
        });
        return true;
      }
      const { firstHeadingLine, headingLines: tabLines, heading, unShiftLines, emptyLines } = getTabLines(editor, editor.getCursor("from").line, editor.getCursor("to").line);
      let normalLines = [];
      for (let index = editor.getCursor("from").line; index < editor.getCursor("to").line + 1; index++) {
        normalLines.push(index);
      }
      let editorChange = composeLineChanges(editor, normalLines, (chunk, heading2, lineNumber) => {
        let tabLen = 1;
        if (chunk.trim() === "") {
          return void 0;
        } else {
          let cur = chunk;
          while (cur.startsWith("    ")) {
            cur = cur.replace("    ", "");
            tabLen += 1;
          }
        }
        return "\n" + applyHeading(chunk.trim(), heading2 + tabLen);
      }, heading);
      editor.transaction({
        changes: [...editorChange]
      });
      return true;
    });
    __publicField(this, "createCommand", () => {
      return {
        id: "change-all-heading",
        name: "Change All to Headings",
        icon: "headingShifter_changeToHeading",
        editorCallback: this.editorCallback
      };
    });
    __publicField(this, "check", () => {
      return true;
    });
    this.settings = settings;
    this.levelUp = levelup;
  }
};
function applyTransation(editor, editorChange) {
  let fromCursor = editor.getCursor("anchor");
  let toCursor = editor.getCursor("head");
  let fromLen = editor.getLine(fromCursor.line).length;
  let toLen = editor.getLine(toCursor.line).length;
  let deltaFrom = 0;
  let deltaTo = 0;
  for (const item of editorChange) {
    if (item.from.line == fromCursor.line) {
      deltaFrom = item.text.length - fromLen;
    }
    if (item.from.line == toCursor.line) {
      deltaTo = item.text.length - toLen;
    }
  }
  let fromTra = { line: fromCursor.line, ch: fromCursor.ch + deltaFrom };
  let toTra = { line: toCursor.line, ch: toCursor.ch + deltaTo };
  editor.transaction({
    changes: editorChange,
    selection: { from: fromTra, to: toTra }
  });
}

// src/services/registerService.ts
var import_state = require("@codemirror/state");
var import_view = require("@codemirror/view");
var ZYRegisterService = class {
  constructor(plugin) {
    __publicField(this, "plugin");
    this.plugin = plugin;
  }
  exec() {
    this.addCommands();
  }
  addCommands() {
    const increaseHeading2 = new ZYIncreaseHeading(this.plugin.settings);
    const decreaseHeading2 = new ZYDecreaseHeading(this.plugin.settings);
    const changeHeading = new ZYChangeHeading(this.plugin.settings, false);
    const changeHeadingUp = new ZYChangeHeading(this.plugin.settings);
    const changeAllHeading = new ZYChangeAllHeading(this.plugin.settings);
    this.plugin.addCommand(increaseHeading2.createCommand());
    this.plugin.addCommand(decreaseHeading2.createCommand());
    this.plugin.addCommand(changeHeading.createCommand());
    this.plugin.addCommand(changeHeadingUp.createCommand());
    this.plugin.addCommand(changeAllHeading.createCommand());
    if (this.plugin.app.vault.getName() == "MapFolder") {
      const tabTypeToggleOperation = new TabTypeToggleOperation(this.plugin.settings);
      const todoToggleOperation = new ZYTODOToggleOperation(this.plugin.settings);
      this.plugin.addCommand(tabTypeToggleOperation.createCommand());
      this.plugin.addCommand(todoToggleOperation.createCommand());
      const enterOperation = new ZYEnterOperation(this.plugin.settings);
      this.plugin.registerEditorExtension(import_state.Prec.highest(import_view.keymap.of([
        {
          key: "Tab",
          run: this.plugin.obsidianService.createKeymapRunCallback({
            check: increaseHeading2.check,
            run: increaseHeading2.editorCallback
          })
        }
      ])));
      this.plugin.registerEditorExtension(import_state.Prec.highest(import_view.keymap.of([
        {
          key: "s-Tab",
          run: this.plugin.obsidianService.createKeymapRunCallback({
            check: decreaseHeading2.check,
            run: decreaseHeading2.editorCallback
          })
        }
      ])));
      this.plugin.registerEditorExtension(import_state.Prec.highest(import_view.keymap.of([
        {
          key: "Enter",
          run: this.plugin.obsidianService.createKeymapRunCallback({
            check: enterOperation.check,
            run: enterOperation.editorCallback
          })
        }
      ])));
    }
  }
};

// src/main.ts
var ZYHeadingShifter = class extends import_obsidian5.Plugin {
  constructor() {
    super(...arguments);
    __publicField(this, "settings");
    __publicField(this, "obsidianService");
    __publicField(this, "interfaceService");
    __publicField(this, "registerService");
  }
  onload() {
    return __async(this, null, function* () {
      this.obsidianService = new ZYObsidianService();
      this.interfaceService = new ZYInterfaceService();
      this.registerService = new ZYRegisterService(this);
      yield this.loadSettings();
      this.addCommand({
        id: `reload-${this.manifest.id}`,
        name: `reload ${this.manifest.name}`,
        callback: () => {
          this.app.plugins.disablePlugin(this.manifest.id);
          this.app.plugins.enablePlugin(this.manifest.id);
        }
      });
      this.registerService.exec();
      this.interfaceService.exec();
    });
  }
  onunload() {
  }
  loadSettings() {
    return __async(this, null, function* () {
      this.settings = Object.assign({}, DEFAULT_SETTINGS, yield this.loadData());
    });
  }
  saveSettings() {
    return __async(this, null, function* () {
      yield this.saveData(this.settings);
    });
  }
};
